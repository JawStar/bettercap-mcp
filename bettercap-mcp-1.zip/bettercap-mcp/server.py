#!/usr/bin/env python3
"""
server.py — bettercap-mcp entry point.

Runs an MCP server over stdio that exposes bettercap (via its REST API,
plus a small controlled CLI surface) as a set of tools, with a
SAFE_MODE-gated allowlist protecting anything that isn't purely
read-only/discovery. Designed for authorized security labs, CTFs,
research, and testing only — see SECURITY.md.

Usage:
    python server.py
    # or, after `pip install -e .`:
    bettercap-mcp

Configure via environment variables / a .env file — see .env.example.
"""
from __future__ import annotations

import logging
import sys

from mcp_compat import MCPApp as FastMCP

from bettercap_cli import BettercapCLI
from bettercap_client import BettercapClient
from config import settings
from context import AppContext
from ollama_client import OllamaClient
from tools import register_all

logging.basicConfig(
    level=getattr(logging, settings.log_level.upper(), logging.INFO),
    # MCP stdio uses stdout for protocol frames — all logging MUST go to stderr.
    stream=sys.stderr,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("bettercap-mcp")


def build_app() -> tuple[FastMCP, AppContext]:
    mcp = FastMCP(settings.server_name)
    ctx = AppContext(
        settings=settings,
        bettercap=BettercapClient(settings),
        cli=BettercapCLI(settings),
        ollama=OllamaClient(settings),
    )
    register_all(mcp, ctx)
    return mcp, ctx


def main() -> None:
    logger.info(
        "Starting %s (SAFE_MODE=%s, bettercap API=%s, ollama=%s)",
        settings.server_name,
        settings.safe_mode,
        settings.api_url,
        settings.ollama_host if settings.ollama_enabled else "disabled",
    )
    mcp, _ctx = build_app()
    # FastMCP.run() defaults to the stdio transport, which is what Claude
    # Desktop, Ollama (via an MCP-aware client), and Open WebUI's MCP
    # bridge all expect for a locally-launched server.
    mcp.run()


if __name__ == "__main__":
    main()
