"""Session-management tools: start/stop modules, inspect state, list what's approved."""
from __future__ import annotations

from mcp_compat import MCPApp as FastMCP

from config import DEFAULT_EXTENDED_MODULES
from context import AppContext
from tools._util import guarded, ok
from validators import validate_command


def register(mcp: FastMCP, ctx: AppContext) -> None:

    @mcp.tool()
    @guarded
    async def bettercap_session_inspect(key: str | None = None) -> str:
        """Inspect the current bettercap session state. Omit `key` for the
        full session object, or pass a dotted sub-path such as 'lan.hosts',
        'gateway', or 'wifi' to fetch just that section. Read-only."""
        if key:
            data = await ctx.bettercap.get_session_key(key)
        else:
            data = await ctx.bettercap.get_session()
        return ok(data)

    @mcp.tool()
    @guarded
    async def bettercap_run_command(command: str) -> str:
        """
        Execute one bettercap interactive-shell command, e.g. 'net.probe on',
        'wifi.recon on', 'net.show', 'get net.probe.running', or 'set
        net.sniff.verbose true'.

        The command is checked against this server's SAFE_MODE allowlist
        before it is ever sent to bettercap. In SAFE_MODE (the default),
        only read-only/discovery modules (net.probe, net.recon, wifi.recon,
        events.stream, ticker, etc.) plus 'get'/'set'/'help'/'clear' are
        permitted — spoofing, proxying, deauth, and cracking modules are
        rejected with a safe_mode_blocked error. Call
        bettercap_list_approved_commands to see exactly what's allowed
        right now.
        """
        parsed = validate_command(command, ctx.settings)
        result = await ctx.bettercap.run_command(parsed.raw)
        return ok({"command": parsed.raw, "result": result})

    @mcp.tool()
    @guarded
    async def bettercap_session_options() -> str:
        """List bettercap's current runtime options/parameters (the output
        of 'get *') for the active session. Read-only."""
        data = await ctx.bettercap.get_session_key("options")
        if data is None:
            # Fallback: some bettercap versions expose params under 'env'.
            session = await ctx.bettercap.get_session()
            data = session.get("env") or session.get("options")
        return ok(data)

    @mcp.tool()
    @guarded
    async def bettercap_list_approved_commands() -> str:
        """
        List exactly which bettercap modules this MCP server will currently
        allow bettercap_run_command to start, given SAFE_MODE and any
        BETTERCAP_MCP_EXTRA_ALLOWED_MODULES configured in the environment.
        Always call this before assuming a module is available.
        """
        allowlist = sorted(ctx.settings.effective_module_allowlist())
        blocked = sorted(
            set(DEFAULT_EXTENDED_MODULES) - ctx.settings.effective_module_allowlist()
        )
        return ok({
            "safe_mode": ctx.settings.safe_mode,
            "always_allowed_verbs": ["get", "set", "help", "clear"],
            "approved_modules": allowlist,
            "blocked_while_safe_mode_on": blocked,
        })
