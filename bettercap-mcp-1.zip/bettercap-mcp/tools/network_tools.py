"""Network reconnaissance tools: discovery, network info, packet stats."""
from __future__ import annotations

from mcp_compat import MCPApp as FastMCP

from context import AppContext
from tools._util import guarded, ok
from validators import ValidationError, validate_command


def register(mcp: FastMCP, ctx: AppContext) -> None:

    @mcp.tool()
    @guarded
    async def bettercap_network_discover(mode: str = "lan") -> str:
        """
        Start passive/active discovery and return what has been seen so far.

        `mode` is one of:
          - 'lan'  : enables net.recon + net.probe (ARP-based host discovery)
          - 'wifi' : enables wifi.recon (802.11 access point / client discovery)
          - 'ble'  : enables ble.recon (Bluetooth LE device discovery)

        All three are read-only recon modules and remain permitted even in
        SAFE_MODE. This only toggles modules on if they are not already
        running; it does not wait for results — call
        bettercap_network_info or bettercap_session_inspect afterward to
        see discovered hosts/APs/devices.
        """
        module_map = {
            "lan": ["net.recon on", "net.probe on"],
            "wifi": ["wifi.recon on"],
            "ble": ["ble.recon on"],
        }
        if mode not in module_map:
            raise ValidationError(f"mode must be one of {list(module_map)}, got {mode!r}")

        results = []
        for cmd in module_map[mode]:
            parsed = validate_command(cmd, ctx.settings)
            results.append({"command": parsed.raw, "result": await ctx.bettercap.run_command(parsed.raw)})

        snapshot: dict = {}
        if mode == "lan":
            snapshot["lan_hosts"] = await ctx.bettercap.get_lan_hosts()
        elif mode == "wifi":
            snapshot["wifi"] = await ctx.bettercap.get_wifi_aps()
        else:
            snapshot["ble"] = await ctx.bettercap.get_ble_devices()

        return ok({"enabled": results, "current_snapshot": snapshot})

    @mcp.tool()
    @guarded
    async def bettercap_network_info() -> str:
        """Get a consolidated read-only view of what bettercap currently
        knows about the network: local interface, gateway, discovered LAN
        hosts, Wi-Fi access points, and BLE devices (whichever recon
        modules have been enabled)."""
        session = await ctx.bettercap.get_session()
        return ok({
            "interface": session.get("interface"),
            "gateway": session.get("gateway"),
            "lan_hosts": (session.get("lan") or {}).get("hosts"),
            "wifi": session.get("wifi"),
            "ble": session.get("ble"),
        })

    @mcp.tool()
    @guarded
    async def bettercap_packet_stats() -> str:
        """Get packet-level statistics from the active session (packets
        seen/sent, protocol breakdown) as reported by bettercap. Read-only."""
        session = await ctx.bettercap.get_session()
        return ok(session.get("packets") or {})
