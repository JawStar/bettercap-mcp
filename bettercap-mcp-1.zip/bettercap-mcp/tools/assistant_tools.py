"""bettercap_assistant — structured AI workflow: gather bettercap data, then
ask a local Ollama model to explain it and suggest the next read-only step.

The MCP server still owns all bettercap execution. Ollama only ever sees
data this server has already fetched and never gets a path to call
bettercap directly — its response is plain text handed back to the
calling MCP client.
"""
from __future__ import annotations

import json

from mcp_compat import MCPApp as FastMCP

from context import AppContext
from tools._util import guarded, ok
from validators import ValidationError

_WORKFLOWS = {
    "network_summary": "Summarize the current network reconnaissance state below and suggest what to check next.",
    "wifi_summary": "Summarize the discovered Wi-Fi access points/clients below and flag anything notable (open networks, WPS, weak encryption) and suggest a next read-only recon step.",
    "event_triage": "Triage the recent bettercap events below: group by type, call out anything that looks like an error or a security-relevant finding, and suggest a next diagnostic step.",
    "packet_stats": "Interpret the packet statistics below in plain language and note anything unusual.",
}


def register(mcp: FastMCP, ctx: AppContext) -> None:

    @mcp.tool()
    @guarded
    async def bettercap_assistant(workflow: str, extra_context: str = "") -> str:
        """
        Run a structured AI-assisted workflow: fetch a relevant slice of
        current bettercap state, then ask the configured local Ollama model
        (OLLAMA_MODEL) to explain it in plain language and suggest the next
        READ-ONLY diagnostic step.

        `workflow` is one of:
          - 'network_summary' : session interface/gateway/LAN hosts
          - 'wifi_summary'    : discovered access points and clients
          - 'event_triage'    : the last 50 bettercap events
          - 'packet_stats'    : packet/protocol statistics

        `extra_context` (optional) is free text you want appended to the
        prompt, e.g. the engagement's scope or a specific question.

        This tool never runs bettercap commands itself and never lets the
        model's suggestions execute automatically — call the appropriate
        bettercap_* tool yourself if you want to act on a suggestion.
        """
        if workflow not in _WORKFLOWS:
            raise ValidationError(f"workflow must be one of {list(_WORKFLOWS)}, got {workflow!r}")

        if not ctx.settings.ollama_enabled:
            return ok({"note": "Ollama integration is disabled (OLLAMA_ENABLED=false)."})

        if workflow == "network_summary":
            session = await ctx.bettercap.get_session()
            data = {
                "interface": session.get("interface"),
                "gateway": session.get("gateway"),
                "lan_hosts": (session.get("lan") or {}).get("hosts"),
            }
        elif workflow == "wifi_summary":
            data = await ctx.bettercap.get_wifi_aps()
        elif workflow == "event_triage":
            data = await ctx.bettercap.get_events(50)
        else:  # packet_stats
            session = await ctx.bettercap.get_session()
            data = session.get("packets") or {}

        prompt_parts = [_WORKFLOWS[workflow], "", "DATA:", json.dumps(data, default=str, indent=2)]
        if extra_context.strip():
            prompt_parts += ["", "ADDITIONAL CONTEXT FROM USER:", extra_context.strip()]
        prompt = "\n".join(prompt_parts)

        if not await ctx.ollama.is_available():
            return ok({
                "raw_data": data,
                "ai_explanation": None,
                "note": f"Ollama at {ctx.settings.ollama_host} is not reachable; returning raw data only.",
            })

        explanation = await ctx.ollama.interpret(prompt)
        return ok({"workflow": workflow, "raw_data": data, "ai_explanation": explanation})

    @mcp.tool()
    @guarded
    async def bettercap_ollama_status() -> str:
        """Check whether the configured Ollama instance is reachable and
        list locally available models."""
        available = await ctx.ollama.is_available()
        models = await ctx.ollama.list_models() if available else []
        return ok({
            "ollama_host": ctx.settings.ollama_host,
            "reachable": available,
            "configured_model": ctx.settings.ollama_model,
            "available_models": models,
        })
