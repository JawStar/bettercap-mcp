"""Shared helpers used by every module under tools/."""
from __future__ import annotations

import functools
import json
from typing import Any, Awaitable, Callable

from bettercap_client import BettercapError
from bettercap_cli import CliError
from ollama_client import OllamaError
from validators import SafeModeError, ValidationError


def ok(data: Any, **extra: Any) -> str:
    """Build the standard successful JSON envelope every tool returns."""
    payload = {"status": "ok", "data": data}
    payload.update(extra)
    return json.dumps(payload, default=str, indent=2)


def err(message: str, *, kind: str = "error", **extra: Any) -> str:
    payload = {"status": "error", "error_type": kind, "message": message}
    payload.update(extra)
    return json.dumps(payload, default=str, indent=2)


def guarded(fn: Callable[..., Awaitable[str]]) -> Callable[..., Awaitable[str]]:
    """
    Decorator for MCP tool functions: converts our expected exception
    types into a structured JSON error response instead of raising, so
    the calling model always gets a well-formed, parseable result.
    """

    @functools.wraps(fn)
    async def wrapper(*args: Any, **kwargs: Any) -> str:
        try:
            return await fn(*args, **kwargs)
        except SafeModeError as exc:
            return err(str(exc), kind="safe_mode_blocked")
        except ValidationError as exc:
            return err(str(exc), kind="validation_error")
        except BettercapError as exc:
            return err(str(exc), kind="bettercap_api_error")
        except CliError as exc:
            return err(str(exc), kind="cli_error")
        except OllamaError as exc:
            return err(str(exc), kind="ollama_error")
        except Exception as exc:  # last resort — never let a raw traceback leak out
            return err(f"Unexpected error: {exc}", kind="internal_error")

    return wrapper
