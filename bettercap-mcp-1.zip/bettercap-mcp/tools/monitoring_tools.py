"""Monitoring tools: sniffer status, event stream inspection."""
from __future__ import annotations

from mcp_compat import MCPApp as FastMCP

from context import AppContext
from tools._util import guarded, ok
from validators import ValidationError, validate_command, validate_positive_int


def register(mcp: FastMCP, ctx: AppContext) -> None:

    @mcp.tool()
    @guarded
    async def bettercap_sniff_control(action: str) -> str:
        """
        Turn the passive packet sniffer (net.sniff) on or off.

        `action` must be 'on' or 'off'. net.sniff only captures and parses
        traffic already reaching this host/interface (e.g. via a SPAN port,
        a hub, or after a separate MITM module has redirected traffic to
        it) — it does not itself intercept or redirect anything, so it is
        permitted under SAFE_MODE.
        """
        if action not in ("on", "off"):
            raise ValidationError("action must be 'on' or 'off'.")
        parsed = validate_command(f"net.sniff {action}", ctx.settings)
        result = await ctx.bettercap.run_command(parsed.raw)
        return ok({"command": parsed.raw, "result": result})

    @mcp.tool()
    @guarded
    async def bettercap_sniff_status() -> str:
        """Report whether net.sniff (and other monitoring-related modules)
        are currently running, per the session's module list."""
        modules = await ctx.bettercap.get_modules() or []
        monitoring = [m for m in modules if m.get("name") in {
            "net.sniff", "events.stream", "net.probe", "net.recon",
            "wifi.recon", "ble.recon",
        }]
        return ok(monitoring)

    @mcp.tool()
    @guarded
    async def bettercap_get_events(count: int = 50) -> str:
        """Fetch the most recent `count` (default 50, max 500) events
        bettercap has logged — discovered hosts, module state changes,
        sniffed protocol events, errors, etc. Read-only."""
        count = validate_positive_int(count, "count", maximum=500)
        events = await ctx.bettercap.get_events(count)
        return ok(events)

    @mcp.tool()
    @guarded
    async def bettercap_clear_events() -> str:
        """Clear bettercap's in-memory event buffer. Useful before starting
        a fresh, isolated observation window."""
        result = await ctx.bettercap.clear_events()
        return ok({"cleared": True, "result": result})
