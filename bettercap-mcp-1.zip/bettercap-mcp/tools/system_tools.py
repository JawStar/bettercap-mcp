"""System-level tools: status, version, doctor, interfaces, modules."""
from __future__ import annotations

from mcp_compat import MCPApp as FastMCP

from context import AppContext
from tools._util import guarded, ok


def register(mcp: FastMCP, ctx: AppContext) -> None:

    @mcp.tool()
    @guarded
    async def bettercap_status() -> str:
        """Get overall status: whether the bettercap REST API is reachable,
        which network interface the running session is bound to, and how
        many modules are currently active. Use this first to confirm
        connectivity before calling any other tool."""
        session = await ctx.bettercap.get_session()
        active_modules = [
            m.get("name") for m in (session.get("modules") or []) if m.get("running")
        ]
        return ok({
            "reachable": True,
            "safe_mode": ctx.settings.safe_mode,
            "interface": (session.get("interface") or {}).get("name"),
            "active_modules": active_modules,
            "targets_seen": len((session.get("lan") or {}).get("hosts") or []),
        })

    @mcp.tool()
    @guarded
    async def bettercap_version() -> str:
        """Get the installed bettercap binary's version string via the
        controlled CLI (no session required)."""
        info = await ctx.cli.get_version()
        return ok(info)

    @mcp.tool()
    @guarded
    async def bettercap_doctor() -> str:
        """Run a read-only environment health check: confirms the bettercap
        binary is present and executable, reports its version, and checks
        that the configured caplets directory exists. Does not touch any
        network interface."""
        report = await ctx.cli.doctor()
        return ok(report)

    @mcp.tool()
    @guarded
    async def bettercap_interfaces() -> str:
        """List the network interface bettercap's active session is bound
        to, along with its IPv4/IPv6/MAC addressing, as reported by the
        REST API."""
        iface = await ctx.bettercap.get_interfaces()
        return ok(iface)

    @mcp.tool()
    @guarded
    async def bettercap_modules() -> str:
        """List every bettercap module known to the running session, its
        running state, and whether the current SAFE_MODE / allowlist
        configuration on THIS server would permit starting it."""
        modules = await ctx.bettercap.get_modules() or []
        allowlist = ctx.settings.effective_module_allowlist()
        annotated = [
            {
                "name": m.get("name"),
                "running": m.get("running"),
                "permitted_by_mcp_allowlist": m.get("name") in allowlist,
            }
            for m in modules
        ]
        return ok({"safe_mode": ctx.settings.safe_mode, "modules": annotated})
