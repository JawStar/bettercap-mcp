"""Caplet tools: list what's on disk, validate a name, run an approved one."""
from __future__ import annotations

from mcp_compat import MCPApp as FastMCP

from context import AppContext
from tools._util import guarded, ok
from validators import validate_caplet_name


def register(mcp: FastMCP, ctx: AppContext) -> None:

    @mcp.tool()
    @guarded
    async def bettercap_list_caplets() -> str:
        """List *.cap caplet files found under the configured caplets
        directory (BETTERCAP_CAPLETS_DIR), and note which ones are
        currently on the BETTERCAP_MCP_ALLOWED_CAPLETS allowlist (if that
        allowlist is configured; an empty allowlist means all listed
        caplets are eligible to run, subject to SAFE_MODE for their
        contents)."""
        names = await ctx.cli.list_caplets()
        allowed = set(ctx.settings.allowed_caplets)
        annotated = [
            {
                "name": n,
                "allowlisted": (not allowed) or (n.rsplit(".cap", 1)[0] in allowed) or (n in allowed),
            }
            for n in names
        ]
        return ok({"caplets_dir": ctx.settings.caplets_dir, "caplets": annotated})

    @mcp.tool()
    @guarded
    async def bettercap_validate_caplet(name: str) -> str:
        """Check whether a caplet name is well-formed (bare filename, no
        path traversal) and permitted by BETTERCAP_MCP_ALLOWED_CAPLETS,
        without running it."""
        base = validate_caplet_name(name, ctx.settings)
        return ok({"name": base, "valid": True, "allowed_to_run": True})

    @mcp.tool()
    @guarded
    async def bettercap_run_caplet(name: str) -> str:
        """
        Run an approved caplet inside the CURRENT running bettercap session
        via the interactive 'include <name>' command.

        The name is validated (bare filename only, no directories/traversal)
        and, if BETTERCAP_MCP_ALLOWED_CAPLETS is set, must appear in that
        allowlist. Note that a caplet's own contents are just a sequence of
        bettercap commands — this tool does not re-validate each line
        inside the caplet against SAFE_MODE, so only point
        BETTERCAP_MCP_ALLOWED_CAPLETS at caplets you have reviewed and trust
        for this environment (see SECURITY.md).
        """
        base = validate_caplet_name(name, ctx.settings)
        result = await ctx.bettercap.run_command(f"include {base}")
        return ok({"caplet": base, "result": result})
