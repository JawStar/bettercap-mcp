"""tools package — each submodule exposes a `register(mcp, ctx)` function."""
from __future__ import annotations

from mcp_compat import MCPApp as FastMCP

from context import AppContext
from tools import (
    assistant_tools,
    caplet_tools,
    monitoring_tools,
    network_tools,
    session_tools,
    system_tools,
)

_MODULES = (
    system_tools,
    session_tools,
    network_tools,
    monitoring_tools,
    caplet_tools,
    assistant_tools,
)


def register_all(mcp: FastMCP, ctx: AppContext) -> None:
    for module in _MODULES:
        module.register(mcp, ctx)
