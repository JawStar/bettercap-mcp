"""
mcp_compat.py — a one-line compatibility shim.

The official `mcp` Python SDK renamed its high-level server class from
`FastMCP` (mcp.server.fastmcp.FastMCP, SDK 1.x) to `MCPServer`
(mcp.server.mcpserver.MCPServer, SDK 2.x). The decorator-based API used
throughout this project (`@mcp.tool()`, `mcp.run()`) is unchanged between
the two, so every other module in this project imports the server class
from here instead of hardcoding one SDK's import path — that keeps
bettercap-mcp working whether the environment has `mcp<2` or `mcp>=2`
installed.

See: https://py.sdk.modelcontextprotocol.io/v2/migration/#fastmcp-renamed-to-mcpserver
"""
from __future__ import annotations

try:
    # mcp >= 2.0
    from mcp.server.mcpserver import MCPServer as MCPApp
except ModuleNotFoundError:
    # mcp < 2.0
    from mcp.server.fastmcp import FastMCP as MCPApp  # type: ignore[no-redef]

__all__ = ["MCPApp"]
