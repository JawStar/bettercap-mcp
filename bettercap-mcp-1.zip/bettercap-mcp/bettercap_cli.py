"""
bettercap_cli.py — the ONLY place in this project that spawns a process.

This exists for the handful of things bettercap's REST API cannot answer
because they concern the binary/host rather than a running session:
version info, a basic environment "doctor" check, and listing caplet
files available on disk. It is deliberately tiny and inflexible:

  * subprocess is invoked with `shell=False` and a fixed argv list built
    from a hardcoded allowlist of operations — no user-controlled string
    is ever concatenated into a command line.
  * Every call has a wall-clock timeout (config.cli_timeout).
  * stdin is closed; nothing here is interactive.
  * No arbitrary caplet execution happens through this module — running
    an actual caplet happens via the validated REST `include <name>`
    command in bettercap_client.py, gated by validators.validate_caplet_name
    and (optionally) BETTERCAP_MCP_ALLOWED_CAPLETS.
"""
from __future__ import annotations

import asyncio
import contextlib
import os
import shutil
from pathlib import Path

from config import Settings
from validators import ValidationError, _SAFE_FILENAME_RE  # reuse the filename pattern


class CliError(RuntimeError):
    pass


class BettercapCLI:
    def __init__(self, settings: Settings):
        self._settings = settings

    def binary_path(self) -> str | None:
        return shutil.which(self._settings.bettercap_binary) or (
            self._settings.bettercap_binary if os.path.isfile(self._settings.bettercap_binary) else None
        )

    async def _run(self, args: list[str]) -> tuple[int, str, str]:
        binary = self.binary_path()
        if binary is None:
            raise CliError(
                f"bettercap binary '{self._settings.bettercap_binary}' was not found on PATH."
            )
        argv = [binary, *args]
        try:
            proc = await asyncio.create_subprocess_exec(
                *argv,
                stdin=asyncio.subprocess.DEVNULL,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(), timeout=self._settings.cli_timeout
            )
        except asyncio.TimeoutError as exc:
            with contextlib.suppress(ProcessLookupError):
                proc.kill()
            raise CliError(f"bettercap CLI call timed out after {self._settings.cli_timeout}s.") from exc
        return proc.returncode, stdout.decode(errors="replace"), stderr.decode(errors="replace")

    async def get_version(self) -> dict:
        code, out, err = await self._run(["-version"])
        return {"returncode": code, "version": out.strip() or err.strip()}

    async def doctor(self) -> dict:
        """A lightweight, read-only environment health check: binary present,
        executable, and able to report its own version. Does not open any
        network interface or require root."""
        result: dict = {"binary_found": False, "executable": False, "version_ok": False, "details": []}
        binary = self.binary_path()
        result["binary_found"] = binary is not None
        if binary is None:
            result["details"].append(f"'{self._settings.bettercap_binary}' not found on PATH.")
            return result
        result["executable"] = os.access(binary, os.X_OK)
        if not result["executable"]:
            result["details"].append(f"'{binary}' is not executable by this process.")
            return result
        try:
            code, out, err = await self._run(["-version"])
            result["version_ok"] = code == 0
            result["details"].append((out or err).strip())
        except CliError as exc:
            result["details"].append(str(exc))
        caplets_dir = Path(self._settings.caplets_dir)
        result["caplets_dir_exists"] = caplets_dir.is_dir()
        if not result["caplets_dir_exists"]:
            result["details"].append(f"Caplets directory not found: {caplets_dir}")
        return result

    async def list_caplets(self) -> list[str]:
        """List *.cap caplet files directly under the configured caplets
        directory — deliberately NOT recursive, so caplets an operator
        has stashed in a subfolder (e.g. reviewed-but-not-activated
        examples) are never auto-discovered or run without an explicit
        move into the top-level directory. Never follows arbitrary paths
        supplied by a caller."""
        caplets_dir = Path(self._settings.caplets_dir)
        if not caplets_dir.is_dir():
            return []
        names = []
        for p in sorted(caplets_dir.glob("*.cap")):
            # only bare, safe names are ever surfaced
            if _SAFE_FILENAME_RE.match(p.name):
                names.append(p.name)
        return names
