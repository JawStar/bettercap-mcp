"""
config.py — centralized, validated configuration for bettercap-mcp.

Everything that controls how aggressively this server can drive bettercap
is defined here and loaded from the environment (optionally via a .env
file). SAFE_MODE and the command allowlist are the primary safety
boundary described in SECURITY.md — change them deliberately, not
accidentally.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

try:
    from dotenv import load_dotenv

    load_dotenv()
except ImportError:  # pragma: no cover - python-dotenv is a soft dependency
    pass


def _env_bool(name: str, default: bool) -> bool:
    val = os.getenv(name)
    if val is None:
        return default
    return val.strip().lower() in {"1", "true", "yes", "on"}


def _env_list(name: str, default: list[str]) -> list[str]:
    val = os.getenv(name)
    if val is None or not val.strip():
        return list(default)
    return [item.strip() for item in val.split(",") if item.strip()]


def _env_int(name: str, default: int) -> int:
    val = os.getenv(name)
    if val is None or not val.strip():
        return default
    try:
        return int(val)
    except ValueError:
        return default


# Modules considered "read-only" / discovery-oriented. These remain usable
# even in SAFE_MODE because they observe traffic/state rather than inject,
# spoof, deauth, or otherwise act on the network.
DEFAULT_SAFE_MODULES: list[str] = [
    "net.probe",
    "net.recon",
    "net.show",
    "net.sniff",
    "wifi.recon",
    "wifi.show",
    "wifi.show.wps",
    "ble.recon",
    "ble.show",
    "events.stream",
    "events.ignore",
    "events.include",
    "ticker",
    "gps",
]

# Modules that actively interfere with traffic (spoofing, MITM, cracking,
# deauthing, jamming). These are BLOCKED unless SAFE_MODE is explicitly
# disabled by the operator, and even then must be present in
# BETTERCAP_MCP_EXTRA_ALLOWED_MODULES or the built-in EXTENDED set below.
DEFAULT_EXTENDED_MODULES: list[str] = [
    "arp.spoof",
    "dns.spoof",
    "dhcp6.spoof",
    "ndp.spoof",
    "http.proxy",
    "https.proxy",
    "http.server",
    "mac.changer",
    "wifi.deauth",
    "wifi.assoc",
    "ble.enum",
    "packet.proxy",
]


@dataclass(frozen=True)
class Settings:
    # --- bettercap REST API -------------------------------------------------
    api_url: str = field(default_factory=lambda: os.getenv(
        "BETTERCAP_API_URL", "http://127.0.0.1:8081"))
    api_username: str = field(default_factory=lambda: os.getenv("BETTERCAP_API_USER", "bettercap"))
    api_password: str = field(default_factory=lambda: os.getenv("BETTERCAP_API_PASSWORD", ""))
    api_verify_tls: bool = field(default_factory=lambda: _env_bool("BETTERCAP_API_VERIFY_TLS", True))
    api_timeout: float = field(default_factory=lambda: float(_env_int("BETTERCAP_API_TIMEOUT", 15)))

    # --- controlled CLI ------------------------------------------------------
    bettercap_binary: str = field(default_factory=lambda: os.getenv("BETTERCAP_BINARY", "bettercap"))
    cli_timeout: float = field(default_factory=lambda: float(_env_int("BETTERCAP_CLI_TIMEOUT", 20)))
    caplets_dir: str = field(default_factory=lambda: os.getenv(
        "BETTERCAP_CAPLETS_DIR", str(Path(__file__).resolve().parent / "caplets")))

    # --- safety boundary -------------------------------------------------
    safe_mode: bool = field(default_factory=lambda: _env_bool("SAFE_MODE", True))
    allowed_modules: list[str] = field(default_factory=lambda: _env_list(
        "BETTERCAP_MCP_ALLOWED_MODULES", DEFAULT_SAFE_MODULES))
    extra_allowed_modules: list[str] = field(default_factory=lambda: _env_list(
        "BETTERCAP_MCP_EXTRA_ALLOWED_MODULES", []))
    allowed_caplets: list[str] = field(default_factory=lambda: _env_list(
        "BETTERCAP_MCP_ALLOWED_CAPLETS", []))
    max_command_length: int = field(default_factory=lambda: _env_int("BETTERCAP_MCP_MAX_CMD_LEN", 512))

    # --- ollama bridge -----------------------------------------------------
    ollama_host: str = field(default_factory=lambda: os.getenv("OLLAMA_HOST", "http://127.0.0.1:11434"))
    ollama_model: str = field(default_factory=lambda: os.getenv("OLLAMA_MODEL", "llama3.1"))
    ollama_timeout: float = field(default_factory=lambda: float(_env_int("OLLAMA_TIMEOUT", 60)))
    ollama_num_ctx: int = field(default_factory=lambda: _env_int("OLLAMA_NUM_CTX", 4096))
    ollama_enabled: bool = field(default_factory=lambda: _env_bool("OLLAMA_ENABLED", True))

    # --- misc ---------------------------------------------------------------
    log_level: str = field(default_factory=lambda: os.getenv("BETTERCAP_MCP_LOG_LEVEL", "INFO"))
    server_name: str = field(default_factory=lambda: os.getenv("BETTERCAP_MCP_SERVER_NAME", "bettercap-mcp"))

    def effective_module_allowlist(self) -> set[str]:
        """Modules the current SAFE_MODE setting permits touching."""
        allowed = set(self.allowed_modules)
        if not self.safe_mode:
            allowed |= set(DEFAULT_EXTENDED_MODULES)
        allowed |= set(self.extra_allowed_modules)
        return allowed


def load_settings() -> Settings:
    return Settings()


settings = load_settings()
