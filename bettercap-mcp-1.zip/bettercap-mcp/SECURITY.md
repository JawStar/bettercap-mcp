# Security Model

`bettercap-mcp` puts a network attack/monitoring framework behind an LLM
tool interface. That combination is only safe when the boundaries below
are understood and kept intact.

## Intended use

This project is for **authorized** security work only: your own lab
network, a CTF you're competing in, a penetration test you are
contracted and scoped for, or academic research on hardware/networks you
own or have written permission to test. Do not point it at networks or
devices you don't own or lack explicit authorization to assess.

## Layered controls

1. **No unrestricted shell execution.** `bettercap_client.py` talks HTTP
   to bettercap's own `api.rest` module. `bettercap_cli.py` is the only
   place a subprocess is spawned, and it only ever runs a hardcoded
   argv (`[bettercap_binary, "-version"]`, etc.) with `shell=False` — no
   user-supplied string is ever concatenated into a command line there.
2. **Allowlist, not denylist.** `validators.py` parses every command
   string and rejects it unless its leading module is in the current
   allowlist (`config.DEFAULT_SAFE_MODULES` plus anything you add via
   `BETTERCAP_MCP_EXTRA_ALLOWED_MODULES`). Unknown/unlisted modules are
   refused, not merely warned about.
3. **SAFE_MODE (default: on).** While on, only read-only/discovery
   modules run: `net.probe`, `net.recon`, `net.sniff`, `wifi.recon`,
   `ble.recon`, `events.stream`, `ticker`, `gps`, plus the always-safe
   verbs `get`/`set`/`help`/`clear`. Traffic-interfering modules
   (`arp.spoof`, `dns.spoof`, `http(s).proxy`, `mac.changer`,
   `wifi.deauth`, etc.) are blocked until you deliberately set
   `SAFE_MODE=false` — a decision that should only be made for a scoped,
   authorized engagement.
4. **Injection-resistant parsing.** Commands containing shell/caplet
   metacharacters (`;`, `&&`, `||`, `|`, backticks, `$( )`, newlines,
   a leading `!` shell-out, or a bare `include`) are rejected outright,
   even for allowlisted modules.
5. **Path-safe caplets.** Caplet names must match a bare-filename
   pattern (no `/`, no `..`); `bettercap_run_caplet` optionally enforces
   an explicit `BETTERCAP_MCP_ALLOWED_CAPLETS` allowlist. **A caplet's
   own contents are not re-validated line-by-line** — only point the
   allowlist at caplets you have personally reviewed.
6. **Localhost-first defaults.** `.env.example` binds the bettercap API
   client and Ollama bridge to `127.0.0.1`. If you expose either over a
   network, put authentication and TLS in front of them — bettercap's
   own `api.rest.username`/`password`/`certificate` parameters, and a
   reverse proxy or firewall rule for Ollama.
7. **Timeouts everywhere.** Every HTTP call (`BETTERCAP_API_TIMEOUT`)
   and subprocess call (`BETTERCAP_CLI_TIMEOUT`) has a bounded timeout so
   a hung bettercap/Ollama instance can't hang the MCP server.
8. **Structured, non-leaking errors.** `tools/_util.py`'s `guarded()`
   decorator catches every expected exception type and any unexpected
   one, returning a structured JSON error instead of letting a raw
   traceback (which could include local paths or internals) reach the
   model.
9. **Ollama is read-only with respect to bettercap.** The
   `bettercap_assistant` tool sends already-fetched data to Ollama for
   *explanation* only. Ollama's text response is returned to the calling
   MCP client; nothing in this codebase automatically executes a
   suggestion Ollama makes.

## What this project deliberately does NOT do

- It does not attempt to sandbox or contain bettercap itself once a
  module is permitted to run — SAFE_MODE controls *which* modules can be
  started, not what a running module is capable of. Running with
  `SAFE_MODE=false` grants the same capability bettercap's own console
  would.
- It does not manage bettercap's own privilege requirements. Packet
  capture/injection modules (e.g. `net.sniff`, `wifi.recon`) typically
  require bettercap itself to run with elevated privileges/capabilities
  on the host — this server does not escalate privileges on your behalf.
- It does not audit or lint caplet contents before running them via
  `bettercap_run_caplet`.

## Reporting a vulnerability

Open a private security advisory on the GitHub repository, or email the
maintainer listed in `pyproject.toml`, rather than filing a public issue.
