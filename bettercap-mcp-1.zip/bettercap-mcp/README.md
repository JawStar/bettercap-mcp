# bettercap-mcp

A production-ready [Model Context Protocol](https://modelcontextprotocol.io)
server that exposes [bettercap](https://www.bettercap.org/) — the Swiss
army knife for 802.11/BLE/IPv4/IPv6 network reconnaissance — to any
MCP-compatible client (Claude Desktop, Ollama-based agents, Open WebUI,
etc.), for **authorized** security labs, CTFs, and research.

Inspired by the shape of
[`techchipnet/aircrack-mcp`](https://github.com/techchipnet/aircrack-mcp),
but talks to bettercap through its **REST API** (`api.rest`) plus a
small, hardcoded **controlled CLI** surface — never an unrestricted
shell — and gates every state-changing command behind a `SAFE_MODE`
allowlist. See [`SECURITY.md`](SECURITY.md) for the full threat model.

> ⚠️ **Only use this against networks and devices you own or are
> explicitly authorized to test.** This tool can drive an active attack
> framework once `SAFE_MODE` is disabled.

## What it exposes

| Category | Tools |
|---|---|
| System | `bettercap_status`, `bettercap_version`, `bettercap_doctor`, `bettercap_interfaces`, `bettercap_modules` |
| Session | `bettercap_session_inspect`, `bettercap_run_command`, `bettercap_session_options`, `bettercap_list_approved_commands` |
| Network | `bettercap_network_discover`, `bettercap_network_info`, `bettercap_packet_stats` |
| Monitoring | `bettercap_sniff_control`, `bettercap_sniff_status`, `bettercap_get_events`, `bettercap_clear_events` |
| Caplets | `bettercap_list_caplets`, `bettercap_validate_caplet`, `bettercap_run_caplet` |
| AI assistant | `bettercap_assistant`, `bettercap_ollama_status` |

Every tool returns a structured JSON envelope:
`{"status": "ok", "data": ...}` or `{"status": "error", "error_type": ..., "message": ...}`.

## Architecture

```
server.py            MCP entry point (FastMCP, stdio transport)
context.py            Shared AppContext (settings + clients)
config.py              Settings loaded from env / .env, SAFE_MODE + allowlists
validators.py           Allowlist + injection-resistant input validation
bettercap_client.py    Async REST client for bettercap's api.rest module
bettercap_cli.py       The ONLY subprocess call site (fixed argv, no shell)
ollama_client.py        Async client for a local Ollama instance
tools/
  system_tools.py       status / version / doctor / interfaces / modules
  session_tools.py      inspect / run_command / options / approved list
  network_tools.py       discovery / network info / packet stats
  monitoring_tools.py    sniffer control+status / events
  caplet_tools.py        list / validate / run approved caplets
  assistant_tools.py      bettercap_assistant + ollama status
tests/                    pytest suite (respx-mocked HTTP, no live bettercap needed)
caplets/                  bundled read-only recon caplets (+ examples/ for reviewed-only extras)
```

## Prerequisites

1. **bettercap** installed and its REST API enabled:
   ```bash
   sudo bettercap -eval "set api.rest.address 127.0.0.1; set api.rest.port 8081; \
     set api.rest.username bettercap; set api.rest.password change-me; api.rest on"
   ```
   (or put those `set`/`api.rest on` lines in a caplet you autorun). bettercap
   typically needs elevated privileges/capabilities to open network interfaces
   for recon/sniffing — grant those to the bettercap process itself, not to
   this MCP server.
2. **Python 3.10+**
3. *(Optional, for `bettercap_assistant`)* **[Ollama](https://ollama.com)**
   running locally with a model pulled, e.g. `ollama pull llama3.1`.

## Install

```bash
git clone https://github.com/JawStar/bettercap-mcp.git
cd bettercap-mcp
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# edit .env: set BETTERCAP_API_PASSWORD to match what you configured above
```

Quick self-check (no live bettercap required for these):

```bash
pytest
```

Run the server directly to confirm it starts (it will idle waiting for
an MCP client on stdio — Ctrl+C to stop):

```bash
python server.py
```

## Connect a client

### Claude Desktop

Add to `claude_desktop_config.json`
(`~/Library/Application Support/Claude/claude_desktop_config.json` on
macOS, `%APPDATA%\Claude\claude_desktop_config.json` on Windows):

```json
{
  "mcpServers": {
    "bettercap": {
      "command": "/absolute/path/to/bettercap-mcp/.venv/bin/python",
      "args": ["/absolute/path/to/bettercap-mcp/server.py"],
      "env": {
        "BETTERCAP_API_URL": "http://127.0.0.1:8081",
        "BETTERCAP_API_USER": "bettercap",
        "BETTERCAP_API_PASSWORD": "change-me",
        "SAFE_MODE": "true",
        "OLLAMA_HOST": "http://127.0.0.1:11434",
        "OLLAMA_MODEL": "llama3.1"
      }
    }
  }
}
```

Restart Claude Desktop; the hammer/tools icon should list the
`bettercap_*` tools.

### Ollama-based agents / custom MCP clients

Any MCP client that speaks stdio (e.g. via
`mcp.client.stdio.stdio_client` from the Python SDK, or an
Ollama-tool-calling agent wired through an MCP bridge) can launch:

```bash
/absolute/path/to/.venv/bin/python /absolute/path/to/server.py
```

as its subprocess and communicate over stdin/stdout, with the same
environment variables as above. This is also what powers
`bettercap_assistant` internally — that tool calls out to Ollama's
own HTTP API (`OLLAMA_HOST`), separately from whatever MCP client is
driving the server.

### Open WebUI

Open WebUI's MCP integration (via its **Tool Servers** / MCPO bridge,
or a compatible MCP-to-OpenAPI proxy such as
[`mcpo`](https://github.com/open-webui/mcpo)) expects an OpenAPI-style
HTTP endpoint in front of an MCP stdio server:

```bash
pip install mcpo
mcpo --port 8000 -- python /absolute/path/to/bettercap-mcp/server.py
```

Then add `http://127.0.0.1:8000` as a Tool Server in Open WebUI's
Settings → Tools. Set the same environment variables (`BETTERCAP_API_URL`,
`SAFE_MODE`, etc.) in the shell that launches `mcpo`, or via a `.env` file
in the working directory — `config.py` loads `.env` automatically.

## Bundled caplets

`caplets/` ships a handful of ready-to-use, read-only recon caplets
(safe under the default `SAFE_MODE=true`), picked up automatically since
`BETTERCAP_CAPLETS_DIR` defaults to this folder:

| Caplet | What it does |
|---|---|
| `lan-recon.cap` | ARP-based LAN host discovery (`net.recon` + `net.probe`), periodic `net.show` |
| `wifi-recon.cap` | Passive 802.11 AP/client discovery (`wifi.recon`) — no deauth/assoc |
| `ble-recon.cap` | Passive Bluetooth LE device discovery (`ble.recon`) |
| `passive-sniff.cap` | Parses traffic already reaching the interface (`net.sniff`) |
| `ctf-triage.cap` | Brings up LAN + Wi-Fi + BLE recon together for a quick "what's here" pass |

Run one with `bettercap_run_caplet(name="lan-recon")`, or list what's
available with `bettercap_list_caplets`.

`caplets/examples/` holds one additional, **inert-by-default** reference
caplet (`arp-mitm-lab.cap.example`) demonstrating an ARP MITM lab setup.
It uses a `.cap.example` extension specifically so it is never
auto-discovered or runnable until you've reviewed it and deliberately
copied it into an allowlisted location — see
`caplets/examples/README.md` and `SECURITY.md` before doing so.

## Usage examples

Ask your MCP client things like:

- *"Check bettercap's status and confirm it's reachable."* → `bettercap_status`
- *"Run a health check on the bettercap install."* → `bettercap_doctor`
- *"Start LAN host discovery and show me what's been found."* → `bettercap_network_discover(mode="lan")`
- *"What commands am I actually allowed to run right now?"* → `bettercap_list_approved_commands`
- *"Turn on the sniffer and summarize the last 50 events with AI."* → `bettercap_sniff_control(action="on")` then `bettercap_assistant(workflow="event_triage")`
- *"List the caplets available and validate `wifi-recon.cap`."* → `bettercap_list_caplets`, `bettercap_validate_caplet(name="wifi-recon.cap")`

## Configuration reference

See [`.env.example`](.env.example) for every variable, in short:

| Variable | Default | Purpose |
|---|---|---|
| `BETTERCAP_API_URL` | `http://127.0.0.1:8081` | bettercap `api.rest` base URL |
| `BETTERCAP_API_USER` / `BETTERCAP_API_PASSWORD` | `bettercap` / *(empty)* | REST basic auth |
| `SAFE_MODE` | `true` | Restrict to read-only/discovery modules |
| `BETTERCAP_MCP_EXTRA_ALLOWED_MODULES` | *(empty)* | Extra modules permitted regardless of SAFE_MODE |
| `BETTERCAP_MCP_ALLOWED_CAPLETS` | *(empty = all)* | Restrict `bettercap_run_caplet` to named caplets |
| `BETTERCAP_CAPLETS_DIR` | bundled `caplets/` | Where `bettercap_list_caplets` looks (non-recursive) |
| `OLLAMA_ENABLED` / `OLLAMA_HOST` / `OLLAMA_MODEL` | `true` / `http://127.0.0.1:11434` / `llama3.1` | AI assistant workflow backend |

## Testing

```bash
pip install -r requirements.txt   # includes pytest, pytest-asyncio, respx
pytest -v
```

The test suite mocks bettercap's REST API with `respx`, so no live
bettercap process is required to validate the allowlist, validators, and
client logic. `tests/test_bettercap_cli.py` exercises the CLI wrapper
against a nonexistent binary path and a temp caplets directory, so it's
also safe to run without bettercap installed.

## Troubleshooting

- **"Could not reach bettercap REST API"** — confirm `api.rest on` is
  active inside bettercap (`bettercap` interactive shell → `api.rest on`
  → check for `api.rest > running` in `help`), and that
  `BETTERCAP_API_URL`/port match what you configured.
- **HTTP 401 from bettercap** — `BETTERCAP_API_USER`/`BETTERCAP_API_PASSWORD`
  don't match `api.rest.username`/`api.rest.password` set inside bettercap.
- **`safe_mode_blocked` errors** — expected for spoofing/proxy/deauth
  modules while `SAFE_MODE=true`. Call `bettercap_list_approved_commands`
  to see what's currently permitted, or add the module to
  `BETTERCAP_MCP_EXTRA_ALLOWED_MODULES` / set `SAFE_MODE=false` if you are
  authorized for that engagement.
- **`bettercap_version`/`bettercap_doctor` report binary not found** —
  set `BETTERCAP_BINARY` to bettercap's full path, or ensure it's on the
  `PATH` of the process that launches `server.py` (Claude Desktop launches
  with its own minimal PATH — use an absolute path in `claude_desktop_config.json`
  or set `BETTERCAP_BINARY` in the `env` block).
- **`bettercap_assistant` says Ollama unreachable** — confirm
  `ollama serve` is running and `OLLAMA_HOST` is correct; `curl
  $OLLAMA_HOST/api/tags` should return JSON.
- **Claude Desktop doesn't show the tools** — check Claude Desktop's MCP
  logs (Settings → Developer), confirm the `command`/`args` paths are
  absolute and the venv's Python has `mcp` installed.

## License

MIT — see `pyproject.toml`. bettercap itself is GPLv3-licensed and is a
separate, independently installed dependency; this project only talks to
it over HTTP/CLI and does not redistribute its code.
