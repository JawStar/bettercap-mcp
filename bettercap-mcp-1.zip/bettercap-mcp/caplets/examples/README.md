# examples/

This folder holds caplets that use **traffic-interfering** bettercap
modules (`arp.spoof`, `net.sniff` in MITM mode, etc.) — the kind that
`SAFE_MODE=true` blocks by design. They are provided as reviewed,
documented starting points for a fully authorized engagement, not as
things this server will run out of the box.

They are kept inert on purpose:

1. Files here use a `.cap.example` extension, not `.cap`, so
   `bettercap_list_caplets`/`bettercap_run_caplet` never see them —
   `bettercap_cli.py` only globs `*.cap` **directly** inside
   `BETTERCAP_CAPLETS_DIR` (non-recursive), and this is a subfolder.
2. Caplet contents are not re-validated line-by-line once `include`d
   (see `SECURITY.md`) — SAFE_MODE only gates which module a *tool
   call* may start, not what a caplet you choose to run does.

## To actually use one

1. Read it. Understand every line.
2. Confirm you are authorized to run active MITM/spoofing modules
   against the target network right now.
3. Copy it into `BETTERCAP_CAPLETS_DIR` with a `.cap` extension.
4. Set `SAFE_MODE=false` (or add the relevant module to
   `BETTERCAP_MCP_EXTRA_ALLOWED_MODULES` — that only affects
   `bettercap_run_command`, not caplets, which is why step 3 still
   matters) and, if you use it, list the caplet explicitly in
   `BETTERCAP_MCP_ALLOWED_CAPLETS`.
