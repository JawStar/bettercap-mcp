"""
bettercap_client.py — async client for bettercap's `api.rest` module.

This talks HTTP(S) + HTTP Basic Auth to an already-running bettercap
process that has `api.rest on` active (see README for setup). It never
spawns bettercap itself and never shells out — that responsibility
belongs to bettercap_cli.py, and only for a small, fixed set of
read-only invocations.

Reference: https://www.bettercap.org/modules/core/apirest/
  GET    /api/session            -> full session state (interface, modules, targets...)
  GET    /api/session/<mod>      -> a sub-key of the session state
  POST   /api/session {"cmd":.} -> execute one interactive-shell command
  GET    /api/events?n=N         -> last N events
  DELETE /api/events             -> clear the event buffer
"""
from __future__ import annotations

import json
from typing import Any

import httpx

from config import Settings


class BettercapError(RuntimeError):
    """Raised for any non-2xx response or transport failure talking to bettercap."""


class BettercapClient:
    def __init__(self, settings: Settings):
        self._settings = settings
        auth = None
        if settings.api_username:
            auth = httpx.BasicAuth(settings.api_username, settings.api_password)
        self._client = httpx.AsyncClient(
            base_url=settings.api_url.rstrip("/"),
            auth=auth,
            verify=settings.api_verify_tls,
            timeout=settings.api_timeout,
        )

    async def aclose(self) -> None:
        await self._client.aclose()

    async def __aenter__(self) -> "BettercapClient":
        return self

    async def __aexit__(self, *exc: Any) -> None:
        await self.aclose()

    async def _request(self, method: str, path: str, **kwargs: Any) -> Any:
        try:
            resp = await self._client.request(method, path, **kwargs)
        except httpx.TransportError as exc:
            raise BettercapError(
                f"Could not reach bettercap REST API at {self._settings.api_url}: {exc}. "
                "Is `api.rest on` active in bettercap?"
            ) from exc
        if resp.status_code == 401:
            raise BettercapError("Authentication to bettercap REST API failed (check credentials).")
        if resp.status_code >= 400:
            raise BettercapError(f"bettercap API {method} {path} -> HTTP {resp.status_code}: {resp.text[:500]}")
        if not resp.content:
            return None
        try:
            return resp.json()
        except json.JSONDecodeError:
            return resp.text

    # ---- session / status -----------------------------------------------
    async def get_session(self) -> dict:
        return await self._request("GET", "/api/session")

    async def get_session_key(self, key: str) -> Any:
        """`key` is a dotted sub-path of the session object, e.g. 'lan.hosts'."""
        return await self._request("GET", f"/api/session/{key}")

    async def get_interfaces(self) -> Any:
        session = await self.get_session()
        return session.get("interface")

    async def get_modules(self) -> Any:
        session = await self.get_session()
        return session.get("modules")

    async def get_gateway(self) -> Any:
        session = await self.get_session()
        return session.get("gateway")

    async def get_lan_hosts(self) -> Any:
        session = await self.get_session()
        return (session.get("lan") or {}).get("hosts")

    async def get_wifi_aps(self) -> Any:
        session = await self.get_session()
        return session.get("wifi")

    async def get_ble_devices(self) -> Any:
        session = await self.get_session()
        return session.get("ble")

    async def get_packet_stats(self) -> Any:
        session = await self.get_session()
        return {
            "packets": session.get("packets"),
            "net_probe_matches": (session.get("modules") or {}),
        }

    # ---- command execution ------------------------------------------------
    async def run_command(self, command: str) -> Any:
        """Execute a single validated interactive-shell command, e.g.
        'net.probe on'. Caller MUST have already run this through
        validators.validate_command."""
        return await self._request("POST", "/api/session", json={"cmd": command})

    # ---- events -------------------------------------------------------------
    async def get_events(self, n: int = 50) -> Any:
        return await self._request("GET", "/api/events", params={"n": n})

    async def clear_events(self) -> Any:
        return await self._request("DELETE", "/api/events")
