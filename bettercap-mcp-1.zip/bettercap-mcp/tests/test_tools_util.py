import json

import pytest

from bettercap_client import BettercapError
from tools._util import guarded, ok
from validators import SafeModeError, ValidationError


@pytest.mark.asyncio
async def test_ok_wraps_data():
    result = json.loads(ok({"a": 1}))
    assert result["status"] == "ok"
    assert result["data"] == {"a": 1}


@pytest.mark.asyncio
async def test_guarded_maps_safe_mode_error():
    @guarded
    async def fn():
        raise SafeModeError("nope")

    result = json.loads(await fn())
    assert result["status"] == "error"
    assert result["error_type"] == "safe_mode_blocked"


@pytest.mark.asyncio
async def test_guarded_maps_validation_error():
    @guarded
    async def fn():
        raise ValidationError("bad input")

    result = json.loads(await fn())
    assert result["error_type"] == "validation_error"


@pytest.mark.asyncio
async def test_guarded_maps_bettercap_error():
    @guarded
    async def fn():
        raise BettercapError("unreachable")

    result = json.loads(await fn())
    assert result["error_type"] == "bettercap_api_error"


@pytest.mark.asyncio
async def test_guarded_never_leaks_raw_traceback():
    @guarded
    async def fn():
        raise KeyError("oops")

    result = json.loads(await fn())
    assert result["error_type"] == "internal_error"
    assert "Traceback" not in result["message"]
