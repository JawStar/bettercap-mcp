"""
Guards against accidentally adding a traffic-interfering caplet under
the top-level caplets/ directory (the one scanned by default). The
examples/ subfolder is exempt — see caplets/examples/README.md — and
isn't picked up by bettercap_cli.list_caplets() anyway since listing is
non-recursive.
"""
from pathlib import Path

from config import DEFAULT_EXTENDED_MODULES

CAPLETS_DIR = Path(__file__).resolve().parent.parent / "caplets"


def _module_tokens(line: str) -> list[str]:
    line = line.split("#", 1)[0].strip()
    if not line:
        return []
    tokens = line.split()
    if tokens[0] == "set" and len(tokens) > 1:
        # e.g. "set ticker.period 15" -> module "ticker"
        return [tokens[1].rsplit(".", 1)[0]]
    # e.g. "net.recon on" -> module "net.recon"
    return [tokens[0]]


def test_bundled_caplets_only_use_safe_modules():
    cap_files = sorted(CAPLETS_DIR.glob("*.cap"))
    assert cap_files, "expected at least one bundled caplet"

    extended = set(DEFAULT_EXTENDED_MODULES)
    offenders = []
    for cap in cap_files:
        for line in cap.read_text().splitlines():
            for module in _module_tokens(line):
                if module in extended:
                    offenders.append((cap.name, line.strip(), module))

    assert not offenders, (
        "Bundled default caplet(s) reference a traffic-interfering module: "
        f"{offenders}. Move it to caplets/examples/ with a .cap.example "
        "extension instead (see caplets/examples/README.md)."
    )


def test_examples_directory_not_auto_discovered():
    examples_dir = CAPLETS_DIR / "examples"
    assert examples_dir.is_dir()
    # The advanced example must NOT use a bare .cap extension, or it
    # would be picked up by BettercapCLI.list_caplets().
    assert not list(examples_dir.glob("*.cap"))
