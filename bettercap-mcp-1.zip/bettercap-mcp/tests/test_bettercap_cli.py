import pytest

from bettercap_cli import BettercapCLI, CliError
from config import Settings


@pytest.mark.asyncio
async def test_missing_binary_raises_cli_error():
    settings = Settings(bettercap_binary="definitely-not-a-real-binary-xyz")
    cli = BettercapCLI(settings)
    assert cli.binary_path() is None
    with pytest.raises(CliError):
        await cli._run(["-version"])  # noqa: SLF001 - intentional internal-method test


@pytest.mark.asyncio
async def test_doctor_reports_missing_binary():
    settings = Settings(bettercap_binary="definitely-not-a-real-binary-xyz")
    cli = BettercapCLI(settings)
    report = await cli.doctor()
    assert report["binary_found"] is False
    assert any("not found" in d for d in report["details"])


@pytest.mark.asyncio
async def test_list_caplets_empty_dir_returns_empty_list(tmp_path):
    settings = Settings(caplets_dir=str(tmp_path))
    cli = BettercapCLI(settings)
    assert await cli.list_caplets() == []


@pytest.mark.asyncio
async def test_list_caplets_finds_cap_files(tmp_path):
    (tmp_path / "recon.cap").write_text("net.recon on\n")
    (tmp_path / "sub").mkdir()
    (tmp_path / "sub" / "wifi.cap").write_text("wifi.recon on\n")
    settings = Settings(caplets_dir=str(tmp_path))
    cli = BettercapCLI(settings)
    names = await cli.list_caplets()
    assert names == ["recon.cap"]  # non-recursive: nested caplets aren't auto-discovered
