import pytest
import respx
from httpx import Response

from bettercap_client import BettercapClient, BettercapError
from config import Settings


@pytest.fixture
def settings() -> Settings:
    return Settings(api_url="http://127.0.0.1:8081", api_username="bettercap", api_password="secret")


@pytest.mark.asyncio
async def test_get_session_returns_json(settings):
    with respx.mock(base_url=settings.api_url) as router:
        router.get("/api/session").mock(
            return_value=Response(200, json={"interface": {"name": "eth0"}, "modules": []})
        )
        async with BettercapClient(settings) as client:
            session = await client.get_session()
    assert session["interface"]["name"] == "eth0"


@pytest.mark.asyncio
async def test_run_command_posts_cmd(settings):
    with respx.mock(base_url=settings.api_url) as router:
        route = router.post("/api/session").mock(return_value=Response(200, json={}))
        async with BettercapClient(settings) as client:
            await client.run_command("net.probe on")
    assert route.called
    sent = route.calls.last.request
    assert b"net.probe on" in sent.content


@pytest.mark.asyncio
async def test_auth_failure_raises_bettercap_error(settings):
    with respx.mock(base_url=settings.api_url) as router:
        router.get("/api/session").mock(return_value=Response(401))
        async with BettercapClient(settings) as client:
            with pytest.raises(BettercapError):
                await client.get_session()


@pytest.mark.asyncio
async def test_unreachable_host_raises_bettercap_error(settings):
    with respx.mock(base_url=settings.api_url) as router:
        router.get("/api/events").mock(side_effect=__import__("httpx").ConnectError("refused"))
        async with BettercapClient(settings) as client:
            with pytest.raises(BettercapError):
                await client.get_events(10)


@pytest.mark.asyncio
async def test_clear_events(settings):
    with respx.mock(base_url=settings.api_url) as router:
        router.delete("/api/events").mock(return_value=Response(200, json={"cleared": True}))
        async with BettercapClient(settings) as client:
            result = await client.clear_events()
    assert result == {"cleared": True}
