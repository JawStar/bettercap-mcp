import pytest

from validators import (
    SafeModeError,
    ValidationError,
    validate_caplet_name,
    validate_command,
    validate_interface,
    validate_positive_int,
    validate_target,
)


class TestValidateCommand:
    def test_allows_readonly_module_in_safe_mode(self, safe_settings):
        parsed = validate_command("net.probe on", safe_settings)
        assert parsed.module == "net.probe"
        assert parsed.verb == "on"

    def test_blocks_spoofing_module_in_safe_mode(self, safe_settings):
        with pytest.raises(SafeModeError):
            validate_command("arp.spoof on", safe_settings)

    def test_allows_spoofing_module_when_safe_mode_off(self, unsafe_settings):
        parsed = validate_command("arp.spoof on", unsafe_settings)
        assert parsed.module == "arp.spoof"

    def test_always_allows_get_set_help_clear(self, safe_settings):
        for cmd in ("get net.probe.running", "set net.sniff.verbose true", "help", "clear"):
            validate_command(cmd, safe_settings)

    @pytest.mark.parametrize("bad", [
        "net.probe on; rm -rf /",
        "net.probe on && whoami",
        "include fb-phish",
        "! id",
        "net.probe `whoami`",
        "net.probe $(whoami)",
    ])
    def test_rejects_injection_attempts(self, safe_settings, bad):
        with pytest.raises(ValidationError):
            validate_command(bad, safe_settings)

    def test_rejects_empty_command(self, safe_settings):
        with pytest.raises(ValidationError):
            validate_command("   ", safe_settings)

    def test_rejects_overlong_command(self, safe_settings):
        with pytest.raises(ValidationError):
            validate_command("net.probe " + "a" * 600, safe_settings)

    def test_extra_allowed_modules_extends_safe_mode(self):
        from config import Settings
        settings = Settings(safe_mode=True, extra_allowed_modules=["arp.spoof"])
        validate_command("arp.spoof on", settings)  # should not raise


class TestValidateInterface:
    def test_accepts_typical_names(self):
        for name in ("eth0", "wlan0", "en0", "Wi-Fi"):
            assert validate_interface(name) == name

    def test_rejects_shell_metacharacters(self):
        with pytest.raises(ValidationError):
            validate_interface("eth0; rm -rf /")


class TestValidateTarget:
    def test_accepts_ipv4_and_cidr_and_mac(self):
        validate_target("192.168.1.1")
        validate_target("192.168.1.0/24")
        validate_target("AA:BB:CC:DD:EE:FF")

    def test_rejects_garbage(self):
        with pytest.raises(ValidationError):
            validate_target("not-a-target; ls")


class TestValidateCapletName:
    def test_accepts_bare_name(self, safe_settings):
        assert validate_caplet_name("recon.cap", safe_settings) == "recon"

    def test_rejects_path_traversal(self, safe_settings):
        with pytest.raises(ValidationError):
            validate_caplet_name("../../etc/passwd", safe_settings)

    def test_enforces_explicit_allowlist(self):
        from config import Settings
        settings = Settings(allowed_caplets=["recon"])
        validate_caplet_name("recon.cap", settings)
        with pytest.raises(SafeModeError):
            validate_caplet_name("fb-phish.cap", settings)


def test_validate_positive_int_bounds():
    assert validate_positive_int(10, "count", maximum=50) == 10
    with pytest.raises(ValidationError):
        validate_positive_int(-1, "count")
    with pytest.raises(ValidationError):
        validate_positive_int(100, "count", maximum=50)
