from config import DEFAULT_EXTENDED_MODULES, DEFAULT_SAFE_MODULES, Settings


def test_defaults_are_safe():
    settings = Settings()
    assert settings.safe_mode is True
    allowlist = settings.effective_module_allowlist()
    for m in DEFAULT_SAFE_MODULES:
        assert m in allowlist
    for m in DEFAULT_EXTENDED_MODULES:
        assert m not in allowlist


def test_disabling_safe_mode_adds_extended_modules():
    settings = Settings(safe_mode=False)
    allowlist = settings.effective_module_allowlist()
    for m in DEFAULT_EXTENDED_MODULES:
        assert m in allowlist


def test_extra_allowed_modules_always_included():
    settings = Settings(safe_mode=True, extra_allowed_modules=["custom.module"])
    assert "custom.module" in settings.effective_module_allowlist()
