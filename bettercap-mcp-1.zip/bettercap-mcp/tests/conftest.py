import sys
from pathlib import Path

import pytest

# Allow `import config`, `import validators`, etc. when running pytest from repo root.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from config import Settings  # noqa: E402


@pytest.fixture
def safe_settings() -> Settings:
    return Settings(
        api_url="http://127.0.0.1:8081",
        api_username="bettercap",
        api_password="test",
        safe_mode=True,
    )


@pytest.fixture
def unsafe_settings() -> Settings:
    return Settings(
        api_url="http://127.0.0.1:8081",
        api_username="bettercap",
        api_password="test",
        safe_mode=False,
    )
