"""
ollama_client.py — bridge to a local Ollama instance.

Ollama is used ONLY to interpret bettercap output and suggest next
diagnostic steps in plain language; it never executes anything itself.
The MCP server (via tools/*.py) remains the sole component allowed to
call bettercap — Ollama's output is text that the calling MCP client
(Claude Desktop, Open WebUI, etc.) or the human operator can choose to
act on by invoking another tool explicitly.
"""
from __future__ import annotations

from typing import Any

import httpx

from config import Settings

SYSTEM_PROMPT = (
    "You are a defensive-minded assistant helping an authorized penetration "
    "tester interpret output from the bettercap network security tool during "
    "a sanctioned engagement, lab, or CTF. Summarize findings clearly, note "
    "anything security-relevant, and suggest the next READ-ONLY diagnostic "
    "step (e.g. which recon module to check next). Do not fabricate data "
    "that isn't in the provided output. Never suggest actions against hosts "
    "or networks the user has not stated they are authorized to test."
)


class OllamaError(RuntimeError):
    pass


class OllamaClient:
    def __init__(self, settings: Settings):
        self._settings = settings
        self._client = httpx.AsyncClient(
            base_url=settings.ollama_host.rstrip("/"),
            timeout=settings.ollama_timeout,
        )

    async def aclose(self) -> None:
        await self._client.aclose()

    async def is_available(self) -> bool:
        try:
            resp = await self._client.get("/api/tags")
            return resp.status_code == 200
        except httpx.TransportError:
            return False

    async def list_models(self) -> list[str]:
        resp = await self._client.get("/api/tags")
        resp.raise_for_status()
        data = resp.json()
        return [m.get("name", "") for m in data.get("models", [])]

    async def interpret(self, prompt: str, *, model: str | None = None) -> str:
        """Send `prompt` (already containing the bettercap data to explain)
        to Ollama's /api/chat and return the assistant's text reply."""
        payload: dict[str, Any] = {
            "model": model or self._settings.ollama_model,
            "messages": [
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": prompt},
            ],
            "stream": False,
            "options": {"num_ctx": self._settings.ollama_num_ctx},
        }
        try:
            resp = await self._client.post("/api/chat", json=payload)
        except httpx.TransportError as exc:
            raise OllamaError(
                f"Could not reach Ollama at {self._settings.ollama_host}: {exc}. "
                "Is `ollama serve` running and OLLAMA_HOST correct?"
            ) from exc
        if resp.status_code == 404:
            raise OllamaError(
                f"Model '{payload['model']}' not found. Pull it first with "
                f"`ollama pull {payload['model']}`."
            )
        if resp.status_code >= 400:
            raise OllamaError(f"Ollama returned HTTP {resp.status_code}: {resp.text[:400]}")
        data = resp.json()
        message = data.get("message") or {}
        return message.get("content", "").strip()
