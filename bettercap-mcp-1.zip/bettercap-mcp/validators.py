"""
validators.py — the actual safety enforcement layer.

Every bettercap command, caplet name, interface name, or target string
that this server forwards to bettercap (REST API or CLI) passes through
here first. Nothing in this module executes anything; it only decides
whether a string is well-formed and permitted.

Design rules:
  * Deny by default. A command must match an explicit pattern for an
    allowed module to pass.
  * No shell metacharacters ever reach subprocess calls (we never use
    shell=True anywhere in this project — see bettercap_cli.py).
  * Caplet and file-path inputs are restricted to a bare filename
    pattern to prevent path traversal.
"""
from __future__ import annotations

import re
import shlex
from dataclasses import dataclass

from config import Settings

# A conservative pattern for the first token of any bettercap command,
# e.g. "net.probe", "wifi.recon", "set", "get", "help".
_MODULE_TOKEN_RE = re.compile(r"^[a-z][a-z0-9_.]*$")

# Dangerous constructs that must never appear in a command string headed
# to bettercap's REST `cmd` field, even though it isn't a shell — this
# blocks caplet `include`/`!`(shell-out) tricks and injection attempts.
_FORBIDDEN_SUBSTRINGS = ("!", "include ", "$(", "`", "\n", "\r", ";", "&&", "||", "|")

# Bare filename only: letters, numbers, dash, underscore, dot — no slashes.
_SAFE_FILENAME_RE = re.compile(r"^[A-Za-z0-9_.-]{1,128}$")

# Interface names on Linux/macOS/Windows are short alnum(+.:-) tokens.
_SAFE_INTERFACE_RE = re.compile(r"^[A-Za-z0-9_.:-]{1,32}$")

# IPv4, IPv4/CIDR, or MAC address.
_SAFE_TARGET_RE = re.compile(
    r"^("
    r"(\d{1,3}\.){3}\d{1,3}(/\d{1,2})?"  # IPv4 or CIDR
    r"|([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}"  # MAC
    r")$"
)

# Read-only / informational verbs that are always safe regardless of module.
_ALWAYS_SAFE_VERBS = {"get", "help", "clear", "events.show"}


class ValidationError(ValueError):
    """A user-supplied value failed input validation."""


class SafeModeError(PermissionError):
    """A requested action is blocked by the current SAFE_MODE / allowlist."""


@dataclass(frozen=True)
class ParsedCommand:
    raw: str
    module: str
    verb: str | None  # e.g. "on" / "off" for "net.probe on"
    tokens: list[str]


def parse_command(command: str) -> ParsedCommand:
    command = command.strip()
    if not command:
        raise ValidationError("Empty command.")
    if len(command) > 512:
        raise ValidationError("Command exceeds maximum allowed length.")
    for bad in _FORBIDDEN_SUBSTRINGS:
        if bad in command:
            raise ValidationError(f"Command contains a forbidden construct: {bad!r}")
    try:
        tokens = shlex.split(command)
    except ValueError as exc:  # unbalanced quotes etc.
        raise ValidationError(f"Could not parse command: {exc}") from exc
    if not tokens:
        raise ValidationError("Empty command.")

    module = tokens[0]
    if not _MODULE_TOKEN_RE.match(module):
        raise ValidationError(f"Invalid module/command token: {module!r}")

    verb = tokens[1] if len(tokens) > 1 else None
    return ParsedCommand(raw=command, module=module, verb=verb, tokens=tokens)


def validate_command(command: str, settings: Settings) -> ParsedCommand:
    """
    Validate `command` against syntax rules and the current allowlist.

    Raises ValidationError for malformed input and SafeModeError when the
    command targets a module that isn't currently permitted.
    """
    parsed = parse_command(command)

    if parsed.module in _ALWAYS_SAFE_VERBS or parsed.module == "set":
        # `set` changes module *parameters*, not whether it runs; still
        # validate the parameter name looks sane.
        if parsed.module == "set" and len(parsed.tokens) < 2:
            raise ValidationError("`set` requires a parameter name.")
        return parsed

    allowlist = settings.effective_module_allowlist()
    if parsed.module not in allowlist:
        raise SafeModeError(
            f"Module '{parsed.module}' is not in the current allowlist "
            f"(SAFE_MODE={'on' if settings.safe_mode else 'off'}). "
            "Add it to BETTERCAP_MCP_EXTRA_ALLOWED_MODULES to permit it."
        )
    return parsed


def validate_interface(name: str) -> str:
    if not _SAFE_INTERFACE_RE.match(name):
        raise ValidationError(f"Invalid interface name: {name!r}")
    return name


def validate_target(target: str) -> str:
    if not _SAFE_TARGET_RE.match(target):
        raise ValidationError(f"Invalid target (expected IPv4[/CIDR] or MAC): {target!r}")
    return target


def validate_caplet_name(name: str, settings: Settings) -> str:
    """Caplet names must be bare filenames (no directories) and, when an
    explicit allowlist is configured, must appear in it."""
    base = name[:-len(".cap")] if name.endswith(".cap") else name
    if not _SAFE_FILENAME_RE.match(base):
        raise ValidationError(f"Invalid caplet name: {name!r}")
    if settings.allowed_caplets and base not in settings.allowed_caplets:
        raise SafeModeError(
            f"Caplet '{base}' is not in BETTERCAP_MCP_ALLOWED_CAPLETS."
        )
    return base


def validate_positive_int(value: int, name: str, maximum: int | None = None) -> int:
    if not isinstance(value, int) or isinstance(value, bool) or value < 0:
        raise ValidationError(f"{name} must be a non-negative integer.")
    if maximum is not None and value > maximum:
        raise ValidationError(f"{name} must not exceed {maximum}.")
    return value
