"""context.py — the small bag of shared objects every tool module needs."""
from __future__ import annotations

from dataclasses import dataclass

from bettercap_cli import BettercapCLI
from bettercap_client import BettercapClient
from config import Settings
from ollama_client import OllamaClient


@dataclass
class AppContext:
    settings: Settings
    bettercap: BettercapClient
    cli: BettercapCLI
    ollama: OllamaClient

    async def aclose(self) -> None:
        await self.bettercap.aclose()
        await self.ollama.aclose()
